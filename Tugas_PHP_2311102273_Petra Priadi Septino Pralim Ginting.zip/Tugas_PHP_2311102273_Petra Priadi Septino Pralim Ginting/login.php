<?php
session_start();

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($_SESSION['users'][$username]) && $_SESSION['users'][$username] == $password) {
        $message = "welcome " . $username;
    } else {
        $message = "wrong username/password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body { font-family: Arial; }
        h1 { color: #333; }
        label { color: #4CAF50; }
        input { display: block; margin: 10px 0; padding: 5px; }
        .btn { background: #4CAF50; color: white; padding: 8px 16px; border: none; cursor: pointer; }
        .link { color: #4CAF50; text-decoration: none; margin-left: 10px; }
        .message { color: #4CAF50; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Login</h1>
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username">
        <label>Password</label>
        <input type="password" name="password">
        <div>
            <button type="submit" class="btn">Login</button>
            <a href="register.php" class="link">Register</a>
        </div>
        <?php if ($message): ?>
            <p class="message"><?= $message ?></p>
        <?php endif; ?>
    </form>
</body>
</html>